//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\ README FILE - 7/28/2016 - "Anger Test" - Quiz Android App
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

A. DISCLAIMER
This disclaimer appoints that the content provided in this app is based on personal opinions and theories, and in no circumstance be utilized as factual content unless proven by an expert in the field of the subject.
This app was developed for educational purposes and to share a personal inside on the subject. Take Anger Test app is not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use, reference to, or reliance on any information contained within the app.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

B. CONTENT
Topic --> Take Anger Test

This app basically measures an estimate rate of anger on the test taker, based on 10 questions where some emotive response is involved.
From Mellow, Applaud, Frustrated and Upset; the app can hypothesize by clasifying the current emotion of test taker by some conditional arguments and ratio clasification.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

C. OPERATIONAL ALGORITHM
1. Open App
2. Click button 'Take'
3. Test screen pos up
4. Read, choose and mark radion buttons with the answer of choice, while scrolling down up to all 10 questions
5. Upon completeing all 10 questions, click the submit button.
6. The test reulsts will be displayed with the analysis hypothesis and an anger rate.
7. Press the 'Quit' button o exit app


//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

D. ALGORITHM HIERARCHY

                                                                         +----------+
									 | OPEN APP |
									 +----------+
									       ^
								      	       |
								        +--------------+	   
									|  PRESS TAKE  |
                                                                        +--------------+
                                                                               ^
                                                                               |
									+-----------------+ 
									| SELECT ANSWER 1 |
									+-----------------+         
								                ^
                                                                                |											
                                                                   +------------------------------+  
					         		   | SCROLL DOWN FOR MORE ANSWERS |
                                                                   +------------------------------+	
							                          ^
								    	  	  |
									   +--------------+		
									   | PRESS SUBMIT |
									   +--------------+
									           ^
									   	   |
							                 +-------------------+		
							                 | READ TEST RESULTS |
							                 +-------------------+
							                            ^
								                    |
				                                              +------------+				
				                                              | PRESS QUIT |
				                                              +------------+
	
		                                                                     ^
				                                                     |
		    	                                                        +----------+   
			                                                        | EXIT APP |
			                                                        +----------+
							   
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
									   

