package com.example.sellingbcom.quiz;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import java.util.Arrays;

/**
 * SHOW DIALOG BOX
 */
public class MainActivity extends Activity {
//GLOBAL VARIABLES
    String content1, content2;
    int q1;
    int q2;
    int q3;
    int q4;
    int q5;
    int q6;
    int q7;
    int q8;
    int q9;
    int q10;

    int r1 = 0;
    int r2 = 0;
    int r3 = 0;
    int r4 = 0;

    int first = 0;
    int second = 0;
    int third = 0;
    int fourth = 0;

    int fIndex;
    int sIndex;
    boolean trigger;

    TextView introText, content1Text, content2Text, content3Text, content4Text, content5Text, conclusionText;
    ImageButton showIntro, hideIntro, showContent1, hideContent1, showContent2, hideContent2, showContent3, hideContent3, showContent4, hideContent4, showContent5, hideContent5, showConclusion, hideConclusion;
//MAIN ACTIVITY HANDLER
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//QUIT APP BUTTON - DEACTIVATED
        Button returnButtonView2 = (Button) findViewById(R.id.quit);
        returnButtonView2.setVisibility(View.GONE);
//QUIT APP BUTTON - HANDLER
        Button btn1 = (Button) findViewById(R.id.quit);
        btn1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                finish();
                System.exit(0);
            }
        });

    }

    /**
     * GET DIALOG BOX TO VIEW
     *
     * @param view
     */
    public void take(View view) {
        CustomDialogClass cdd = new CustomDialogClass(MainActivity.this);
        cdd.show();
    }
//GENERATE EMOTION
    public String get(int obj1) {
        String emotion = "";
        if (obj1 == 0) {
            emotion = "Mellow";
        } else if (obj1 == 1) {
            emotion = "Applaud";
        } else if (obj1 == 2) {
            emotion = "Frustrated";
        } else if (obj1 == 3) {
            emotion = "Upset";
        }

        return emotion;
    }

    //REPLACE TITLE
    public void newTitle(String content1) {
        ImageView returnButtonView = (ImageView) findViewById(R.id.image1);
        returnButtonView.setVisibility(View.GONE);
        TextView priceTextView = (TextView) findViewById(R.id.newTitle);
        priceTextView.setText(content1);
    }
//TEST HANDLER
    public void submitTest(String content2) {
        Button returnButtonView = (Button) findViewById(R.id.startBtn);
        returnButtonView.setVisibility(View.GONE);
        Button returnButtonView2 = (Button) findViewById(R.id.quit);
        returnButtonView2.setVisibility(View.VISIBLE);
        TextView priceTextView = (TextView) findViewById(R.id.responseText);
        priceTextView.setText(content2);
    }

    /**
     * START DIALOG BOX
     */
    public class CustomDialogClass extends Dialog implements
            android.view.View.OnClickListener {

        public Activity c;
        public Dialog d;
        public Button submit;

        public CustomDialogClass(Activity a) {
            super(a);

            this.c = a;
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            setContentView(R.layout.quiz_screen);

            submit = (Button) findViewById(R.id.btn_submit);

            submit.setOnClickListener(this);


        }
//SUBMITTED TEST
        @Override
        public void onClick(View v) {
            switch (v.getId()) {

                case R.id.btn_submit:
                    /*
                    Get Data
                     */

                    String emoType1 = "", emoType2 = "", emoType3 = "", emoType4 = "";
                    //get selected radio button from radioGroup
                    RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.q_1);
                    int selectedId1 = radioGroup1.getCheckedRadioButtonId();
                    RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.q_2);
                    int selectedId2 = radioGroup2.getCheckedRadioButtonId();
                    RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.q_3);
                    int selectedId3 = radioGroup3.getCheckedRadioButtonId();
                    RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.q_4);
                    int selectedId4 = radioGroup4.getCheckedRadioButtonId();
                    RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.q_5);
                    int selectedId5 = radioGroup5.getCheckedRadioButtonId();
                    RadioGroup radioGroup6 = (RadioGroup) findViewById(R.id.q_6);
                    int selectedId6 = radioGroup6.getCheckedRadioButtonId();
                    RadioGroup radioGroup7 = (RadioGroup) findViewById(R.id.q_7);
                    int selectedId7 = radioGroup7.getCheckedRadioButtonId();
                    RadioGroup radioGroup8 = (RadioGroup) findViewById(R.id.q_8);
                    int selectedId8 = radioGroup8.getCheckedRadioButtonId();
                    RadioGroup radioGroup9 = (RadioGroup) findViewById(R.id.q_9);
                    int selectedId9 = radioGroup9.getCheckedRadioButtonId();
                    RadioGroup radioGroup10 = (RadioGroup) findViewById(R.id.q_10);
                    int selectedId10 = radioGroup10.getCheckedRadioButtonId();

                    //find the radio button by returned id
                    RadioButton osButton1 = (RadioButton) findViewById(selectedId1);
                    RadioButton osButton2 = (RadioButton) findViewById(selectedId2);
                    RadioButton osButton3 = (RadioButton) findViewById(selectedId3);
                    RadioButton osButton4 = (RadioButton) findViewById(selectedId4);
                    RadioButton osButton5 = (RadioButton) findViewById(selectedId5);
                    RadioButton osButton6 = (RadioButton) findViewById(selectedId6);
                    RadioButton osButton7 = (RadioButton) findViewById(selectedId7);
                    RadioButton osButton8 = (RadioButton) findViewById(selectedId8);
                    RadioButton osButton9 = (RadioButton) findViewById(selectedId9);
                    RadioButton osButton10 = (RadioButton) findViewById(selectedId10);

        /*
          Make Calculation Here
        */
                    String selection1 = (String) osButton1.getText();
                    String selection2 = (String) osButton2.getText();
                    String selection3 = (String) osButton3.getText();
                    String selection4 = (String) osButton4.getText();
                    String selection5 = (String) osButton5.getText();
                    String selection6 = (String) osButton6.getText();
                    String selection7 = (String) osButton7.getText();
                    String selection8 = (String) osButton8.getText();
                    String selection9 = (String) osButton9.getText();
                    String selection10 = (String) osButton10.getText();

                    //IDENTIFY RADIO TEXT AND SET VALUE
                    if (selection1.startsWith("M")) {
                        q1 = 1;
                    } else if (selection1.startsWith("A")) {
                        q1 = 2;
                    } else if (selection1.startsWith("F")) {
                        q1 = 3;
                    } else if (selection1.startsWith("U")) {
                        q1 = 4;
                    }
                    if (selection2.startsWith("M")) {
                        q2 = 1;
                    } else if (selection2.startsWith("A")) {
                        q2 = 2;
                    } else if (selection2.startsWith("F")) {
                        q2 = 3;
                    } else if (selection2.startsWith("U")) {
                        q2 = 4;
                    }
                    if (selection3.startsWith("M")) {
                        q3 = 1;
                    } else if (selection3.startsWith("A")) {
                        q3 = 2;
                    } else if (selection3.startsWith("F")) {
                        q3 = 3;
                    } else if (selection3.startsWith("U")) {
                        q3 = 4;
                    }
                    if (selection4.startsWith("M")) {
                        q4 = 1;
                    } else if (selection4.startsWith("A")) {
                        q4 = 2;
                    } else if (selection4.startsWith("F")) {
                        q4 = 3;
                    } else if (selection4.startsWith("U")) {
                        q4 = 4;
                    }
                    if (selection5.startsWith("M")) {
                        q5 = 1;
                    } else if (selection5.startsWith("A")) {
                        q5 = 2;
                    } else if (selection5.startsWith("F")) {
                        q5 = 3;
                    } else if (selection5.startsWith("U")) {
                        q5 = 4;
                    }
                    if (selection6.startsWith("M")) {
                        q6 = 1;
                    } else if (selection6.startsWith("A")) {
                        q6 = 2;
                    } else if (selection6.startsWith("F")) {
                        q6 = 3;
                    } else if (selection6.startsWith("U")) {
                        q6 = 4;
                    }
                    if (selection7.startsWith("M")) {
                        q7 = 1;
                    } else if (selection7.startsWith("A")) {
                        q7 = 2;
                    } else if (selection7.startsWith("F")) {
                        q7 = 3;
                    } else if (selection7.startsWith("U")) {
                        q7 = 4;
                    }
                    if (selection8.startsWith("M")) {
                        q8 = 1;
                    } else if (selection8.startsWith("A")) {
                        q8 = 2;
                    } else if (selection8.startsWith("F")) {
                        q8 = 3;
                    } else if (selection8.startsWith("U")) {
                        q8 = 4;
                    }
                    if (selection9.startsWith("M")) {
                        q9 = 1;
                    } else if (selection9.startsWith("A")) {
                        q9 = 2;
                    } else if (selection9.startsWith("F")) {
                        q9 = 3;
                    } else if (selection9.startsWith("U")) {
                        q9 = 4;
                    }
                    if (selection10.startsWith("M")) {
                        q10 = 1;
                    } else if (selection10.startsWith("A")) {
                        q10 = 2;
                    } else if (selection10.startsWith("F")) {
                        q10 = 3;
                    } else if (selection10.startsWith("U")) {
                        q10 = 4;
                    }

                    //STORE VALUES
                    int[] arraySet = {q1, q2, q3, q4, q5, q6, q7, q8, q9, q10};
                    //int [] arraySet =  {2, 2, 3, 1, 1, 1, 4, 4, 4, 4};

                    //COUNT REPETITIONS
                    for (int i = 0; i < 10; i++) {
                        if (arraySet[i] == 1) {
                            r1++;
                        }
                        if (arraySet[i] == 2) {
                            r2++;
                        }
                        if (arraySet[i] == 3) {
                            r3++;
                        }
                        if (arraySet[i] == 4) {
                            r4++;
                        }
                    }

//SET FINAL VALUES
                    int[] arraySet2 = {r1, r2, r3, r4};
                    //Arrays.sort(arraySet2);
//SELECT PARAMETERS AND DESIGNATE EMOTION
                    for (int i = 0; i < 4; i++) {
                        if (arraySet2[i] > first) {
                            first = arraySet2[i];
                            fIndex = i;
                        } else if (arraySet2[i] < second || second == 0) {

                            second = arraySet2[i];
                            sIndex = i;
                            if (first == second) {
                                trigger = true;
                            }
                            if (sIndex == 0) {
                                sIndex = 1;
                            }
                            if (sIndex == 3) {
                                sIndex = 2;
                            }

                        }
                    }
//GENERATE REULTS
                    if (trigger) {
                        String testResult = "You are " + get(fIndex) + " most of the time.";
                        testResult += "\n Your anger rate is of " + r4 * 10 + "%";
                        submitTest(testResult);
                        newTitle("Result");
                        break;
                    } else {
                        String testResult = "Normally you are " + get(fIndex) + " and sometimes you are " + get(sIndex) + ".";
                        testResult += "\n Your anger rate is of " + r4 * 10 + "%";
                        submitTest(testResult);
                        newTitle("Result");
                        break;
                    }

                default:
                    break;
            }
            dismiss();

        }
    }


}
